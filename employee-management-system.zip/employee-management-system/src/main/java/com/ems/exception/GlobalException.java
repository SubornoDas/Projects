package com.ems.exception;

public class GlobalException extends RuntimeException {
public GlobalException(String message) {
	super(message);
}
}
