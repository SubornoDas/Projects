package com.ems;

import java.time.LocalDate;
import java.util.Scanner;

import javax.swing.JOptionPane;

import com.ems.entity.Employee;
import com.ems.service.AdminService;
import com.ems.service.EmployeeService;
import com.ems.service.ManagerService;
import com.ems.serviceimpl.AdminServiceImpl;
import com.ems.serviceimpl.EmployeeServiceImpl;
import com.ems.serviceimpl.ManagerServiceImpl;

public class App 
{
	static Scanner sc=new Scanner(System.in);
    public static void main( String[] args )
    {
    	mainMenu();
    }
    public static void mainMenu() {
    	int ch;
    	do {
        System.out.println("|=============== Welcome to Employee Management System ===============| ");
        System.out.println("1) Admin\n2) Employee and Department\n3) Manager\n4) Exit");
    //    ch=sc.nextInt();
        ch=Integer.parseInt(JOptionPane.showInputDialog("Enter choice:","Type here"));
        switch(ch)
        {
        case 1: mainadmin();
        	break;
      
        case 2:
        	mainUser();
        case 3:
        	mainManager();
        	break;
        case 4:
        	System.exit(0);
        	default:
        		System.out.println("Wrong Input !!!");
        }
    	}while(ch!=4);
    }

	private static void mainUser() {
		// TODO Auto-generated method stub
		System.out.println();
		do {
		//EmployeeService empService=new EmployeeServiceImpl();
		System.out.println("|=============== EMPLOYEE AND DEPARTMENT ===============|");
		System.out.println("(A) Save new employee");
		System.out.println("(B) Get employee details by ID");
		System.out.println("(C) To update employee details");
		System.out.println("(D) To delete an employee");
		System.out.println("(E) Save new department");
		System.out.println("(F) Get department details by ID");
		System.out.println("(G) Update department details by Id");
		System.out.println("(H) Delete department details using id");
		System.out.println("(I) Assign department to employee");
		System.out.println("(J) To get employee details using email");
		System.out.println("(k) Return to Main Menu");
		//char choice = sc.next().charAt(0);
		String choice=JOptionPane.showInputDialog("Enter choice: ","Type here....");
		switch(choice)
		{
		case "A":
			EmployeeCRUD.saveEmployee();
			break;
		case "B":
			EmployeeCRUD.getEmployee();
			break;
		case "C":
			EmployeeCRUD.updateEmployee();
			break;
		case "D":
			EmployeeCRUD.deleteEmployee();
			break;
		case "E" :
			DepartmentCRUD.addDepartment();
			break;
		case "F":
			DepartmentCRUD.getDepartment();
			break;
		case "G":
			DepartmentCRUD.updateDepartmentUsingId();
			break;
		case "H":
			DepartmentCRUD.deleteDepartmentUsingId();
			break;
		case "I":
			DepartmentCRUD.assign();
			break;
		case "J":
			EmployeeCRUD.getEmployeeByEmail();
		case "k":
			App.mainMenu();
			break;
		
	//		Employee emp= new Employee();
//		
//			sc.nextLine();
//			System.out.println("Enter name : ");
//			String name=sc.nextLine();
//			System.out.println("Enter address : ");
//			String add=sc.nextLine();
//			System.out.println("Enter salary : ");
//			double sal=sc.nextDouble();
//			System.out.println("Enter contact no : ");
//			String cont=sc.next();
//			sc.nextLine();
//			System.out.println("Enter email : ");
//			String email=sc.nextLine();
//			System.out.println("Enter designation : ");
//			String des=sc.nextLine();
//			System.out.println("Enter DOJ : ");
//			LocalDate date=LocalDate.parse(sc.next());  //yyyy-mm-dd
//			System.out.println("Enter username : ");
//			String user=sc.nextLine();
//			sc.nextLine();
//			System.out.println("Enter password : ");
//			String pass=sc.nextLine();			 
//			
//			
//			emp.setEmpName(name);
//			emp.setEmpAddress(add);
//			emp.setSalary(sal);
//			emp.setContact(cont);
//			emp.setEmail(email);
//			emp.setDesignation(des);
//			emp.setDOJ(date);
//			emp.setUserName(user);
//			emp.setPassword(pass);
//			emp.setRole("employee");
////			
//			empService.saveEmployee(emp);
//			System.out.println("Employee details saved !!!");
//			break;
//		}
	}
		}while(true);
	}
	public static void mainadmin() {
		System.out.println();
		do {
		AdminService adminService=new AdminServiceImpl();
		System.out.println("|============== ADMIN ================|");
		System.out.println("A) Save new admin"
				+ "\nB) Login\nC) Return to Main Menu");
		String choice=JOptionPane.showInputDialog("Enter choice :","Type here..");
		switch(choice) {
		case "A":
			AdminCRUD.saveAdmin();
			
			break;
		case "B":
			boolean status=adminService.login(JOptionPane.showInputDialog("Enter user_name:","Type here.."),JOptionPane.showInputDialog("Enter password:","Type here.."));
			if(status==true) {
				
				AdminCRUD.afterLoginAdmin();
			}
			else {
				
				JOptionPane.showMessageDialog(null, "Wrong Credentials");
			}
			//AdminCRUD.login();
			break;
		case "C":
				App.mainMenu();
				break;
		
			
		}
		}while(true);
	}
	private static void mainManager() {
		System.out.println();
		ManagerService mgrService=new ManagerServiceImpl();
		System.out.println("|=================== MANAGER ===================|");
		System.out.println("A) Save new manager"
						+"\nB) To fetch the details of manager using id"
						+"\nC) To update manager details by id"
						+"\nD) To delete manager by id"
						+"\nE) Assign employee to manager"
						+"\nF) Return to Main Menu");
				
		String choice=JOptionPane.showInputDialog("Enter choice:","Type here..");
		switch(choice) {
		case "A":
			ManagerCRUD.saveManager();
			break;
		case "B":
			ManagerCRUD.getManagerById();
			break;
		case "C":
			ManagerCRUD.updateManagerById();
			break;
		case "D":
			ManagerCRUD.deleteManagerById();
			break;
		case "E":
			ManagerCRUD.assignEmployeeToManager();
			break;
		case "F":
			App.mainMenu();
			break;
			
		}
	}
	}

